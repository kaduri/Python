import Signal_Driver
import RS232
import time

'''
DOP>debug jesd2_rx capt peak
freq_if_khz=87000
freq_rf_khz=1573000
dbfs=-13.019
dbm=-7.519

'''
cable_loss =  0
inbandSteps = 11
Signal_Driver.init_gpib_instr()
Signal_Driver.set_sig_Mod_output("OFF")                                                                 # turn off signal generator modulation mode
Signal_Driver.set_sig_output("ON")
signalGeneratorFreq = 818
signalGeneratorAmplitude = -13.7 # -13.6 for spltr; -15.0 for PMC direct; -32.9 for cable without ATT

COM_Number = 2                                                                                          #com number
BaudRate = 115200                                                                                       #baud rate
serial = False
serial_number= "_SN007-02_07_2018-08_00"
if(RS232.init_serial(COM_Number,BaudRate)== 0):                                                         #init uart com and baud rate
    exit()

f= open(f'c:\\dpam_pdet_results\\ul_ripple{serial_number}.csv',"w+")

jesd_rx_number = "jesd1_rx"
power_reads =[]

RS232.writeToUartCli("debug jesd2_rx capt peak")

for i in range(inbandSteps):
    Signal_Driver.set_sig_freq_and_amp(signalGeneratorFreq + i*3, signalGeneratorAmplitude+cable_loss)                       #control on signal generator
    time.sleep(10)                                                                                       #delay 2sec for stabilty
    current_value = RS232.writeToUartCli(f'debug {jesd_rx_number} capt peak')               #send command to uart and return raw value
    current_value[0]="-"+str(current_value[0])+"."+current_value[1]
                                                                               #print the valure - only for debug
    current_value_update = current_value[0]
    print(current_value_update)
    power_reads.append(current_value)
    RS232.Uart_clear_buffers()                                                                          #clear uart buffers
    time.sleep(0.2)
    print(f'{signalGeneratorFreq+i*3},{current_value_update}')  #print with our paramters
    f.write(f'{signalGeneratorFreq+i*3},{current_value_update}\n')

max_value = max(power_reads)
min_value = min(power_reads)

ripple = float(max_value[0])-float(min_value[0])
print (ripple)
f.write(f'Total Ripple, {ripple}\n')
f.close()


