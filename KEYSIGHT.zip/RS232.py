import serial
import time
import re
import sys
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *

import math

#global Variables
ser =0
COM_NUM=1
baudrate = 115200



#Function to Initialize the Serial Port

def init_serial(COM_NUM,baudrate):
    #COM_NUM = 1       # COM Port Number
    global ser        # Must be declared in Each Function
    global counter
    ser = serial.Serial()
    ser.baudrate = baudrate
    ser.port = "COM{}".format(COM_NUM)  # COM Port Name Start from 1

    ser.timeout = 10  #Timeout in seconds
    try:
        
        ser.open() # ***

        if ser.isOpen():
            print ('Open: ' + ser.portstr)
            ser.flushInput() #flush input buffer, discarding all its contents
            ser.flushOutput()#flush output buffer, aborting current output 
                                         #and discard all that is in buffer
            print ("Connected")
            return 1 # 1 is ok
    except serial.serialutil.SerialException:
        print ("Cannot open COM %d" % (COM_NUM))
        #msg = QMessageBox()
        #msg.setText("Cannot open COM%d" % (COM_NUM))
        #msg.exec_()
        return 0
#Function init_serial End

def Uart_clear_buffers():
    ser.flushInput()  # flush input buffer, discarding all its contents
    ser.flushOutput()  # flush output buffer, aborting current output
    # and discard all that is in buffer


def make_macro(cli_command):
    print ("sendln '%s'" %(cli_command))

def writeToUartCli(cli_command):
    temp = cli_command+"\n"
    temp = temp.encode('utf-8')
    ser.write(temp)
    time.sleep(0.1)
    print (temp)

    if(ReadLineFromUartCli('Ok')==False):
        temp = cli_command+"\n"
        temp = temp.encode('utf-8')
        ser.write(temp)
        print (temp)
    return raw_result

def writeToUartCli_power_detector(cli_command):
    temp = cli_command+"\n"
    temp = temp.encode('utf-8')
    ser.write(temp)
    time.sleep(0.1)
    print (temp)



def writeToUartGeneral(command):
    temp = command + "\n"
    temp = temp.encode('utf-8')
    ser.write(temp)
    time.sleep(0.1)
    print (temp)

def writeToUartSpecial(cli_command,sWaitString):
    
    temp = cli_command+"\n"
    temp = temp.encode('utf-8')
    ser.write(temp)
    time.sleep(0.1)
    print (temp)
    if ReadLineFromUartCli(sWaitString)==False:
        temp = cli_command+"\n"
        ser.write(temp)
        print (temp + "CLI Sending number %s" % ("0"))
        foundStatus = False
    else:
        foundStatus = True

    return foundStatus


#move this lines to function and call to this function from Main function GUI        
#init_serial(COM_NUM) # call the Serial Initilization Function, Main program starts from here

def ReadFromUartWithSpecialResult(sWaitString):
    time.sleep(0.1)
    if (ReadLineFromUartCli(sWaitString) == False):
        print  ("CLI Ready")

def ReadLineFromUartCli(sSubstring):
    time.sleep(0.1)
    status=False
    timeout = 10 #  - one cycle 0.1
    re_try_maximum = 3
    counter = 0
    while True:
        time.sleep(0.01)
        counter+=1
        #print counter
        if sSubstring=="send_only":
            print ("break due to send_only")
            break
        response = ser.readline()
        if response==None:
            try_again_numbers=0
            for i in range(re_try_maximum):
                response = ser.readline()
                if response is not None:
                    i=re_try_maximum
                else:
                    try_again_numbers=try_again_numbers+1
            if try_again_numbers==re_try_maximum:
                print ("uart reading error")
                temp = "\n"
                ser.write(temp)
                break
        print(response)


        m = re.search('table', response.decode("utf-8"))      #only for power detector reading
        if m:
            print ("**********Found Raw!!!!!************")
            print(response)                                 #saving raw value
            response = ser.readline()
            print(response)
            if len(response)>20:
                global raw_result
                raw_result=response

        m = re.search('dbfs', response.decode("utf-8"))      #only for power detector reading - changed to raw instead of Raw(27.6.18)
        if m:
            print ("**********Found dbfs!!!!!************")
            print(response)                                 #saving raw value
            p = re.compile(r'\d+')

            raw_result = p.findall(response.decode("utf-8"))

        m = re.search('raw', response.decode("utf-8"))      #only for power detector reading - changed to raw instead of Raw(27.6.18)
        if m:
            print ("**********Found raw!!!!!************")
            print(response)                                 #saving raw value
            p = re.compile(r'\d+')

            raw_result = ''.join(p.findall(response.decode("utf-8")))

        m = re.search(sSubstring, response.decode("utf-8"))    #waiting for Ok response
        if m:
            print ("**********found RC=%s FOR CLI Number %s!************" % (sSubstring,"0"))
            status=True
            #raw_result = '0'
            break
        
        m = re.search('failed', response.decode("utf-8"))
        if m:
            print ("**********Bad Paramters - Write failed - please check your setup parameters!************")
            msg = QMessageBox()
            msg.setText("Bad Paramters - Write failed - please check your setup parameters")
            msg.exec_()
            status=True
            #raw_result = '0'
            break
            
        m = re.search('Bad', response.decode("utf-8"))
        if m:
            print ("**********Bad Paramters - will try again!************")
            #raw_result = '0'
            status=False




        if counter > timeout:
            break

    return status


#def close_com(ser):



#Ctrl+C to Close Python Window
