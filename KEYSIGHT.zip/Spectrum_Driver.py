import time
import pyVISA
import string
import re
import math
from Corning.VISA import rack




#global Variables
number_of_send_receive_retries= 3

#save the data in "struct"
class SA_Struct():
    def __init__(self, SA_Freq_Start, SA_Freq_Stop, SA_Freq_Center):
        self.SA_Freq_Start = SA_Freq_Start
        self.SA_Freq_Stop = SA_Freq_Stop
        self.SA_Freq_Center = SA_Freq_Center


#global Variables of our Spectrum Analyzer - database parameters
SA_Gen_Address = "GPIB1::1::INSTR"
SA_Freq_Start = 1850.0
SA_Freq_Stop = 1915.0
SA_Freq_Center = (SA_Freq_Start + SA_Freq_Stop)/2

MySA_Struct = SA_Struct(SA_Freq_Start, SA_Freq_Stop, SA_Freq_Center)


def init_gpib_instr():
    addresses=pyVISA.VISAFind("GPIB?*INSTR").address
    for addr in addresses:
        inst=pyVISA.Instr(addr)
        s=inst.Query("*IDN?").strip()
        print (s)

# Spectrum Generator Declaration name
SA=pyVISA.Instr(SA_Gen_Address)


def set_SA_ref_level_(ref_level):
    '''set Spectrum Analyzer center frequency (dB)'''
    SA.Write("DISP:WIND:TRAC:Y:RLEV %s dBm" % (ref_level))


def set_SA_ref_level_offset(ref_level_offset):
    '''set Spectrum Analyzer center frequency (dB)'''
    SA.Write("DISP:WIND:TRAC:Y:RLEV:OFFS %s" % (ref_level_offset))

def set_SA_freq_center(freq):
    '''set Spectrum Analyzer center frequency (MHz)'''
    SA.Write("FREQ:CENT %s MHZ" % (freq))

def set_SA_freq_start(freq):
    '''set Spectrum Analyzer start frequency (MHz)'''
    SA.Write("FREQ:STAR %s MHZ" % (freq))

def set_SA_freq_stop(freq):
    '''set Spectrum Analyzer stop frequency (MHz)'''
    SA.Write("FREQ:STOP %s MHZ" % (freq))

def set_SA_span(span_mhz):
    '''set Spectrum Analyzer span (MHz)'''
    SA.Write("FREQ:SPAN %s MHZ" % (span_mhz))

def set_trace_max_hold():
    '''set Max Hold function)'''
    SA.Write("TRAC:TYPE MAXH")

def set_SA_restart():
    '''set restart measurements'''
    SA.Write(":INIT:REST")
    time.sleep(1)

def get_SA_amp(freq):
    '''set Spectrum Analyzer center frequency (MHz) and return the peak by marker peak'''
    SA.Write("FREQ:CENT %s MHZ" % (freq))
    time.sleep(1)   # signal max hold stability time
    SA.Write("CALC:MARK:MAX")
    value = SA.Query(":CALC:MARK1:Y?")
    return float(re.search('[+-]?\d+(\.\d+)?([eE][+-]?\d+)?', value).group())

def get_marker_amp(freq):
    SA.Write("CALC:MARK1:STAT ON")
    SA.Write("CALC:MARK1:X %s MHZ" % (freq))
    time.sleep(0.5) #sweep time
    value = SA.Query(":CALC:MARK1:Y?")
    return float(re.search('[+-]?\d+(\.\d+)?([eE][+-]?\d+)?', value).group())

    #return float(re.sub("\s|\\\\n|'|\\\\", '', value))

    #print value
'''
    #new_val,val = value.split("\\n")
    #new_val, val = new_val.split('')
    #print new_val
    
    s = new_val
    match_number = re.compile('-?\ *[0-9]+\.?[0-9]*(?:[Ee]\ *-?\ *[0-9]+)?')
    final_list = [float(x) for x in re.findall(match_number, s)]
    print final_list
    new_value = final_list[0]
    new_value = new_value * (final_list[1]*10)
    print new_value
'''

def reset():
    SA.Write("*RST")
    time.sleep(1)

def basic_cpri_set_up(SA_Freq_Start,SA_Freq_Stop):
    set_SA_restart()
    set_SA_freq_start(SA_Freq_Start)
    set_SA_freq_stop(SA_Freq_Stop)
    set_trace_max_hold()
    set_SA_restart()




#SA Test Driver-------------------------------------------------------------------------------------------------
'''
init_gpib_instr()

get_marker_amp("1880")

set_SA_freq_start("2000")
set_SA_freq_stop("2300")
set_trace_max_hold()
#set_SA_restart()
'''

'''
init_gpib_instr()
SA.Write("*RST")
SA.Write(":MMEM:STOR:SCR 'C:\Report\Image.png'")
'''


#sa=rack.SA('GPIB0::1::INSTR')
#sa.SaveScreenImage('c:/report/jojo.png')

