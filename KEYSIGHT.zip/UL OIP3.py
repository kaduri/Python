import Signal_Driver1
import Signal_Driver2
import RS232
import time


#setup connections
cable_loss =  0
inbandSteps = 3
Signal_Driver1.init_gpib_instr()
Signal_Driver1.set_sig_Mod_output("OFF")                                                                 # turn off signal generator modulation mode
Signal_Driver1.set_sig_output("ON")
Signal_Driver2.init_gpib_instr()
Signal_Driver2.set_sig_Mod_output("OFF")                                                                 # turn off signal generator modulation mode
Signal_Driver2.set_sig_output("ON")
signalGeneratorFreq1 = 833
signalGeneratorFreq2 = 836
signalGeneratorAmplitude1 = -16.7 # -13.6 for spltr; -15.0 for PMC direct; -32.9 for cable without ATT
signalGeneratorAmplitude2 = -16.7 # -13.6 for spltr; -15.0 for PMC direct; -32.9 for cable without ATT
TargetTonePower = -17
DeltaTonePower = 0.2
delayForCapture = 10 #sec
ip3Spacing = 3
results_for_report=[]

leftFreqIMD = signalGeneratorFreq1 - ip3Spacing
rightFreqIMD = signalGeneratorFreq2 + ip3Spacing


COM_Number = 2                                                                                          #com number
BaudRate = 115200                                                                                       #baud rate
serial = False
serial_number= "_SN007-02_07_2018-08_00"
if(RS232.init_serial(COM_Number,BaudRate)== 0):                                                         #init uart com and baud rate
    exit()

f= open(f'c:\\dpam_pdet_results\\ul_ip3{serial_number}.csv',"w+")

jesd_rx_number = "jesd1_rx"
power_reads =[]

Signal_Driver1.set_sig_freq_and_amp(signalGeneratorFreq1,signalGeneratorAmplitude1)
Signal_Driver2.set_sig_freq_and_amp(signalGeneratorFreq2,signalGeneratorAmplitude2)

print("Please wait - capture processing...")
time.sleep(delayForCapture)

RS232.writeToUartCli(f'debug {jesd_rx_number} capt peak {signalGeneratorFreq1-1}000 {signalGeneratorFreq1+1}000')


current_value = RS232.writeToUartCli(f'debug {jesd_rx_number} capt peak {signalGeneratorFreq1-1}000 {signalGeneratorFreq1+1}000')
measuredLeftTone="-"+str(current_value[0])+"."+current_value[1]

current_value = RS232.writeToUartCli(f'debug {jesd_rx_number} capt peak {signalGeneratorFreq2-1}000 {signalGeneratorFreq2+1}000')
measuredRightTone="-"+str(current_value[0])+"."+current_value[1]


print("Left tone power " + measuredLeftTone+"dBFs")
print("Right tone power " + measuredRightTone+"dBFs")

#Adjust Power per tone to the target
leftDelta = TargetTonePower - float(measuredLeftTone)
if (abs(leftDelta) > abs(DeltaTonePower)):
    signalGeneratorAmplitude1 = signalGeneratorAmplitude1 + leftDelta
    Signal_Driver1.set_sig_freq_and_amp(signalGeneratorFreq1,signalGeneratorAmplitude1)

rightDelta = TargetTonePower - float(measuredRightTone)
if (abs(rightDelta) > abs(DeltaTonePower)):
    signalGeneratorAmplitude2 = signalGeneratorAmplitude2 + rightDelta
    Signal_Driver2.set_sig_freq_and_amp(signalGeneratorFreq2,signalGeneratorAmplitude2)

print("Please wait - capture processing after power fixing...")
time.sleep(delayForCapture)

current_value = RS232.writeToUartCli(f'debug {jesd_rx_number} capt peak {signalGeneratorFreq1-1}000 {signalGeneratorFreq1+1}000')
measuredLeftTone="-"+str(current_value[0])+"."+current_value[1]
current_value = RS232.writeToUartCli(f'debug {jesd_rx_number} capt peak {signalGeneratorFreq2-1}000 {signalGeneratorFreq2+1}000')
measuredRightTone="-"+str(current_value[0])+"."+current_value[1]

print("Left tone power " + measuredLeftTone+"dBFs")
print("Right tone power " + measuredRightTone+"dBFs")

def MeasureIntermodes():
    results =[]
    # Measure Left Intermode--------------------------------------------------------------------------------------------
    current_value = RS232.writeToUartCli(f'debug {jesd_rx_number} capt peak {leftFreqIMD-1}000 {leftFreqIMD+1}000')
    measuredLeftIMD="-"+str(current_value[0])+"."+current_value[1]
    results.append(measuredLeftIMD)
    # Measure Right Intermode--------------------------------------------------------------------------------------------
    current_value = RS232.writeToUartCli(f'debug {jesd_rx_number} capt peak {rightFreqIMD-1}000 {rightFreqIMD+1}000')
    measuredRightIMD="-"+str(current_value[0])+"."+current_value[1]
    results.append(measuredRightIMD)
    print("Left IMD power " + measuredLeftIMD+"dBFs")
    print("Right IMD power " + measuredRightIMD+"dBFs")

    return results

f.write(f'LeftFreq,RightFreq,Spacing,LeftTonePower,RightTonePower,LeftIMDLevel,RightIMDLevel,LeftIMDDelta,RightIMDDelta,LeftOIP3,RightOIP3,OIP3\n')

for i in range(3):
    print(f'Please wait for interaction number {i+1}')
    time.sleep(delayForCapture)

    results_for_report = MeasureIntermodes()
    measuredLeftIMD = results_for_report[0]
    measuredRightIMD = results_for_report[1]
    # XLS Report--------------------------------------------------------------------------------------------------------
    measuredLeftTone = float (measuredLeftTone)
    measuredRightTone = float (measuredRightTone)
    measuredLeftIMD = float (measuredLeftIMD)
    measuredRightIMD = float (measuredRightIMD)
    oip3Left = measuredLeftTone  + (measuredLeftTone-measuredLeftIMD)/2
    oip3Right = measuredRightTone + (measuredRightTone-measuredRightIMD)/2
    oip3 = min(oip3Left,oip3Right)
    f.write(f'{signalGeneratorFreq1},{signalGeneratorFreq2},{ip3Spacing},{measuredLeftTone},{measuredRightTone},{measuredLeftIMD},{measuredRightIMD},{measuredLeftTone-measuredLeftIMD},{measuredRightTone-measuredRightIMD},{oip3Left},{oip3Right},{oip3}\n')

f.close()

'''

class Oip3():

    def __init__(self,centerFreq,Spacing):
         self.centerFreq = centerFreq
         self.Spacing = Spacing

    def measureIP3(self):
        x=5
        imdPower=-50
        return imdPower
'''


