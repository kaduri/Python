#include "extcode.h"
#pragma pack(push)
#pragma pack(1)

#ifdef __cplusplus
extern "C" {
#endif

int32_t __cdecl VISAWrite(char Address[], char writeBuffer[]);
void __cdecl VISAFind(char FindExpression[], char Addresses[], 
	uint32_t *Count, int32_t len);
void __cdecl VISARead(char Address[], uint32_t byteCount, char readBuffer[], 
	int32_t len);

long __cdecl LVDLLStatus(char *errStr, int errStrLen, void *module);

#ifdef __cplusplus
} // extern "C"
#endif

#pragma pack(pop)

