import telnetlib, socket, time


class TELNET(object):
    def __init__(self,host,port,timeout=5):
        self.tn = None
        self.password = ""
        self.host = host
        self.port=port
        self.timeout=timeout
        self.password_prompt=b"Enter Password:"

    def connect(self):
        try:
            self.tn=telnetlib.Telnet(self.host,self.port,self.timeout)
        except socket.timeout:
            print("TELNET.connect() socket.timeout")

    def login(self):
        raise("Login is not implemented yet")


    def write(self, msg):
        #self.tn.write (msg.encode ('ascii') + b"\n\r")
        self.tn.write(f"{msg}\n\r".encode())
        return True


    def _read_very_eager(self):
        try :
            return self.tn.read_very_eager()
        except socket.timeout :
            print("read_very_eager socket.timeout")
            return False

    def read_buffer(self,delay):
        s = b''
        count = 0
        count_max = self.timeout/delay
        while len(s) < 3 and count<count_max:
            s += self._read_very_eager()
            time.sleep(delay)
            count+=1

        return s

    def close(self):
        self.tn.close()
        return True






