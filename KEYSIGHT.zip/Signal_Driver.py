import time
import pyVISA


#global Variables
number_of_send_receive_retries= 3

#save the data in "struct"
class SIG_Struct():
    def __init__(self, SIG_Freq_Start, SIG_Freq_Stop, SIG_Freq_Center,SIG_Amp):
        self.SIG_Freq_Start = SIG_Freq_Start
        self.SIG_Freq_Stop = SIG_Freq_Stop
        self.SIG_Freq_Center = SIG_Freq_Center
        self.SIG_Amp = SIG_Amp


#global Variables of our Signal Generator - database parameters
Sig_Gen_Address = "GPIB1::2::INSTR"
SIG_Freq_Start = 1930.0
SIG_Freq_Stop = 1995.0
SIG_Freq_Center = (SIG_Freq_Start + SIG_Freq_Stop)/2
SIG_Amp = -40
SIG_Sweep_number_of_points = 1000

MySIG_Struct = SIG_Struct(SIG_Freq_Start, SIG_Freq_Stop, SIG_Freq_Center,SIG_Amp)


def init_gpib_instr():
    addresses=pyVISA.VISAFind("GPIB?*INSTR").address
    for addr in addresses:
        inst=pyVISA.Instr(addr)
        s=inst.Query("*IDN?").strip()
        print (s)

# Signal Generator Declaration name
Sig=pyVISA.Instr(Sig_Gen_Address)

def set_sig_output(mode):
    ''' Send ON for on mode and send OFF for off mode '''
    Sig.Write("OUTP %s" % (mode))

def set_sig_Mod_output(mode):
    ''' Send ON for on mode and send OFF for off mode '''
    Sig.Write("OUTP:MOD %s" % (mode))

def set_sig_freq_and_amp(freq, amp):
    '''set signal generator freq (MHz) and amp (dB)'''
    Sig.Write("FREQ %s MHZ" % (freq))
    Sig.Write("POW %s DBM" % (amp))

def set_sig_sweep_freq_start(freq):
    '''set signal sweep mode generator - start freq (MHz)'''
    Sig.Write("FREQ:STAR %d MHZ" % (freq))

def set_sig_sweep_freq_stop(freq):
    '''set signal sweep mode generator - stop freq (MHz)'''
    Sig.Write("FREQ:STOP %d MHZ" % (freq))

def set_sig_sweep_points(number_of_points):
    '''set signal generator sweep mode - number of points for sweep'''
    Sig.Write("SWE:POIN %d" % (number_of_points))

def set_sig_sweep_freq_mode(mode):
    '''set signal generator sweep mode - MODE is CW|FIXed|LIST'''
    Sig.Write("FREQ:MODE %s"% (mode))
    Sig.Write("INIT:CONT:ALL ON")

def reset():
    Sig.Write("*RST")

def basic_cpri_set_up(SIG_Freq_Start,SIG_Freq_Stop):
    init_gpib_instr()  # only for test
    reset()
    set_sig_freq_and_amp(SIG_Freq_Center, SIG_Amp)
    set_sig_Mod_output("OFF")
    set_sig_output("ON")
    set_sig_sweep_freq_start(SIG_Freq_Start)
    set_sig_sweep_freq_stop(SIG_Freq_Stop)
    set_sig_sweep_points(SIG_Sweep_number_of_points)
    set_sig_sweep_freq_mode("LIST")


    # set_sig_output("OFF")

#SIG Test driver-----------------------------------------------------------------------------------------------------
'''
init_gpib_instr()   #only for test
set_sig_freq_and_amp(SIG_Freq_Center, SIG_Amp)
set_sig_Mod_output("OFF")
set_sig_output("OFF")
'''

'''
set_sig_sweep_freq_start(SIG_Freq_Start)
set_sig_sweep_freq_stop(SIG_Freq_Stop)
set_sig_sweep_points(SIG_Sweep_number_of_points)
set_sig_sweep_freq_mode("LIST")
#set_sig_output("OFF")
'''



