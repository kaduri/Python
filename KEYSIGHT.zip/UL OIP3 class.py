import Signal_Driver1
import Signal_Driver2
import RS232
import time


#help process functions
# 1. init parameters
# 1.1. Set SignalGenerators
# 2. TonesMeasurement with warning message input
# 3. Adjust Power per tone to the target
# 4. TonesMeasurement with warning message input
# 5. MeasureIntermodes
# 6. CreateTitleReport
# 7. RepaetImdMeas - consider to replace with AVE
# 8. SaveToFile
# 9. CloseFile


class Oip3():

    def __init__(self,centerFreq,Spacing):
         self.centerFreq = centerFreq  #not used
         self.Spacing = Spacing        #not used

         # COM Setup Parameters---------------------
         self.COM_Number = 2  # com number
         self.BaudRate = 115200  # baud rate
         self.serial = False
         if (RS232.init_serial(self.COM_Number, self.BaudRate) == 0):  # init uart com and baud rate
             exit()
         # -----------------------------------------------------

         # Init Instruments--------------------------------------
         Signal_Driver1.init_gpib_instr()
         Signal_Driver1.set_sig_Mod_output("OFF")  # turn off signal generator modulation mode
         Signal_Driver1.set_sig_output("ON")
         Signal_Driver2.init_gpib_instr()
         Signal_Driver2.set_sig_Mod_output("OFF")  # turn off signal generator modulation mode
         Signal_Driver2.set_sig_output("ON")

         # setup connections
         self.cable_loss = 0
         self.inbandSteps = 3
         self.signalGeneratorFreq1 = 833
         self.signalGeneratorFreq2 = 836
         self.signalGeneratorAmplitude1 = -16.7 # -13.6 for spltr; -15.0 for PMC direct; -32.9 for cable without ATT
         self.signalGeneratorAmplitude2 = -16.7 # -13.6 for spltr; -15.0 for PMC direct; -32.9 for cable without ATT
         self.TargetTonePower = -17
         self.DeltaTonePower = 0.2
         self.delayForCapture = 10 #sec
         self.ip3Spacing = 3
         self.results_for_report=[]

         self.leftFreqIMD = self.signalGeneratorFreq1 - self.ip3Spacing
         self.rightFreqIMD = self.signalGeneratorFreq2 + self.ip3Spacing

         self.jesd_rx_number = "jesd1_rx"
         self.power_reads =[]
         # Create Report File --------------------
         self.serial_number= "_SN007-02_07_2018-08_00"
         self.f= open(f'c:\\dpam_pdet_results\\ul_ip3{self.serial_number}.csv',"w+")
         # --------------------------------------

         # SG Configuration: Freq and Power ---------------------
    def SetSignalGenerators(self):
        Signal_Driver1.set_sig_freq_and_amp(self.signalGeneratorFreq1,self.signalGeneratorAmplitude1)
        Signal_Driver2.set_sig_freq_and_amp(self.signalGeneratorFreq2,self.signalGeneratorAmplitude2)
         #  -----------------------------------------------------

         # RS232.writeToUartCli(f'debug {self.jesd_rx_number} capt peak {self.signalGeneratorFreq1-1}000 {self.signalGeneratorFreq1+1}000')

    # Tones Measurement----------------------------------------------------------------
    #msg1 "Please wait - capture processing..."

    def TonesMeasurement(self, msg):
        print (msg)
        time.sleep(self.delayForCapture)
        current_value = RS232.writeToUartCli(f'debug {self.jesd_rx_number} capt peak {self.signalGeneratorFreq1-1}000 {self.signalGeneratorFreq1+1}000')
        self.measuredLeftTone="-"+str(current_value[0])+"."+current_value[1]
        current_value = RS232.writeToUartCli(f'debug {self.jesd_rx_number} capt peak {self.signalGeneratorFreq2-1}000 {self.signalGeneratorFreq2+1}000')
        self.measuredRightTone="-"+str(current_value[0])+"."+current_value[1]
        print("Left tone power " + self.measuredLeftTone+"dBFs")
        print("Right tone power " + self.measuredRightTone+"dBFs")
    #----------------------------------------------------------------

    #Adjust Power per tone to the target
    def AdjustPowerPerToneToTheTarget(self):
        leftDelta = self.TargetTonePower - float(self.measuredLeftTone)
        if (abs(leftDelta) > abs(self.DeltaTonePower)):
            if (leftDelta < 10):
                self.signalGeneratorAmplitude1 = self.signalGeneratorAmplitude1 + leftDelta
                Signal_Driver1.set_sig_freq_and_amp(self.signalGeneratorFreq1, self.signalGeneratorAmplitude1)
            else:
                print("Please check freqs - warning high amplitude for left tone!!!!")
                exit()

        rightDelta = self.TargetTonePower - float(self.measuredRightTone)
        if (abs(rightDelta) > abs(self.DeltaTonePower)):
            if (rightDelta<10):
                self.signalGeneratorAmplitude2 = self.signalGeneratorAmplitude2 + rightDelta
                Signal_Driver2.set_sig_freq_and_amp(self.signalGeneratorFreq2,self.signalGeneratorAmplitude2)
            else:
                print("Please check freqs - warning high amplitude for right tone!!!!")
                exit()

    def MeasureIntermodes(self):
        self.results =[]
        # Measure Left Intermode--------------------------------------------------------------------------------------------
        current_value = RS232.writeToUartCli(f'debug {self.jesd_rx_number} capt peak {self.leftFreqIMD-1}000 {self.leftFreqIMD+1}000')
        measuredLeftIMD="-"+str(current_value[0])+"."+current_value[1]
        self.results.append(measuredLeftIMD)
        # Measure Right Intermode--------------------------------------------------------------------------------------------
        current_value = RS232.writeToUartCli(f'debug {self.jesd_rx_number} capt peak {self.rightFreqIMD-1}000 {self.rightFreqIMD+1}000')
        measuredRightIMD="-"+str(current_value[0])+"."+current_value[1]
        self.results.append(measuredRightIMD)
        print("Left IMD power " + measuredLeftIMD+"dBFs")
        print("Right IMD power " + measuredRightIMD+"dBFs")

        return self.results

    def CreateTitleReport(self):
        self.f.write(f'LeftFreq,RightFreq,Spacing,LeftTonePower,RightTonePower,LeftIMDLevel,RightIMDLevel,LeftIMDDelta,RightIMDDelta,LeftOIP3,RightOIP3,OIP3\n')

    def RepaetImdMeas(self):

        time.sleep(self.delayForCapture)
        self.results_for_report = self.MeasureIntermodes()
        self.measuredLeftIMD = self.results_for_report[0]
        self.measuredRightIMD = self.results_for_report[1]
        # XLS Report--------------------------------------------------------------------------------------------------------
        self.measuredLeftTone = float (self.measuredLeftTone)
        self.measuredRightTone = float (self.measuredRightTone)
        self.measuredLeftIMD = float (self.measuredLeftIMD)
        self.measuredRightIMD = float (self.measuredRightIMD)
        self.oip3Left = self.measuredLeftTone  + (self.measuredLeftTone-self.measuredLeftIMD)/2
        self.oip3Right = self.measuredRightTone + (self.measuredRightTone-self.measuredRightIMD)/2
        self.oip3 = min(self.oip3Left,self.oip3Right)
        self.f.write(f'{self.signalGeneratorFreq1},{self.signalGeneratorFreq2},{self.ip3Spacing},{self.measuredLeftTone},{self.measuredRightTone},{self.measuredLeftIMD},{self.measuredRightIMD},{self.measuredLeftTone-self.measuredLeftIMD},{self.measuredRightTone-self.measuredRightIMD},{self.oip3Left},{self.oip3Right},{self.oip3}\n')



    def SaveToFile(self):

        self.measuredLeftIMD = self.results_for_report[0]
        self.measuredRightIMD = self.results_for_report[1]
        # XLS Report--------------------------------------------------------------------------------------------------------
        self.measuredLeftTone = float (self.measuredLeftTone)
        self.measuredRightTone = float (self.measuredRightTone)
        self.measuredLeftIMD = float (self.measuredLeftIMD)
        self.measuredRightIMD = float (self.measuredRightIMD)
        self.oip3Left = self.measuredLeftTone  + (self.measuredLeftTone-self.measuredLeftIMD)/2
        self.oip3Right = self.measuredRightTone + (self.measuredRightTone-self.measuredRightIMD)/2
        self.oip3 = min(self.oip3Left,self.oip3Right)
        self.f.write(f'{self.signalGeneratorFreq1},{self.signalGeneratorFreq2},{self.ip3Spacing},{self.measuredLeftTone},{self.measuredRightTone},{self.measuredLeftIMD},{self.measuredRightIMD},{self.measuredLeftTone-self.measuredLeftIMD},{self.measuredRightTone-self.measuredRightIMD},{self.oip3Left},{self.oip3Right},{self.oip3}\n')

    def CloseFile(self):
        self.f.close()



# 1. init parameters
Oip3_test = Oip3(836,6)
# 2. TonesMeasurement with warning message input
Oip3_test.SetSignalGenerators()

Oip3_test.TonesMeasurement("Please wait - capture processing...")
# 3. Adjust Power per tone to the target
Oip3_test.AdjustPowerPerToneToTheTarget()
# 4. TonesMeasurement with warning message input
Oip3_test.TonesMeasurement("Please wait - capture processing - after fixing...")
# 5. MeasureIntermodes
Oip3_test.MeasureIntermodes()
# 6. CreateTitleReport
Oip3_test.CreateTitleReport()
# 7. RepaetImdMeas - consider to replace with AVE
for i in range(3):
    print(f'Please wait for interaction number {i+1}')
    Oip3_test.RepaetImdMeas()
    # 8. SaveToFile

# 9. CloseFile
Oip3_test.CloseFile()

