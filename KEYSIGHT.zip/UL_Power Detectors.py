import Signal_Driver
import RS232
import time

#setup connections
COM_Number = 5                                                                                          #com number
BaudRate = 115200                                                                                       #baud rate
serial = False
serial_number= "_SN007-02_07_2018-08_00"
#time.struct_time (tm_year=2018, tm_mon=6, tm_mday=26, tm_hour=16, tm_min=56)
Signal_Driver.init_gpib_instr()                                                                         #init signal generator communication
if(RS232.init_serial(COM_Number,BaudRate)== 0):                                                         #init uart com and baud rate
    exit()
f= open(f'c:\dpam_pdet_results\pd{serial_number}.csv',"w+")                                                             #file name for saving the results

Signal_Driver.Sig_Gen_Address = "GPIB1::2::INSTR"

#power detector paramters
PowerDetector_pdetname = "ul_pdet"                                                                      #power detector name
PowerDetector_NumberOfSteps = 40                                                                      # number of points for power detector
PowerDetector_freq = 833                                                                        # center frequncy for signal generator
pd_start = -62    # power detector - starting calib value
cable_loss = 24.3
powerDetector_reads =[]                                                                                 # prepare a list to stock up the reads
Signal_Driver.set_sig_Mod_output("OFF")                                                                 # turn off signal generator modulation mode
Signal_Driver.set_sig_output("ON")                                                                      # turn on signal generator RF mode
#RS232.writeToUartCli("control mode ate")
current_raw_value = RS232.writeToUartCli(f'monitor ul pdet {PowerDetector_pdetname}')



for i in range(PowerDetector_NumberOfSteps):
    Signal_Driver.set_sig_freq_and_amp(PowerDetector_freq, pd_start+i+cable_loss)                       #control on signal generator
    time.sleep(2)                                                                                       #delay 2sec for stabilty
    current_raw_value = RS232.writeToUartCli(f'monitor ul pdet {PowerDetector_pdetname}')               #send command to uart and return raw value
    print(current_raw_value)                                                                            #print the valure - only for debug
    if (i>0):                                                                                           #for case of same follow values (noise levels)
        if (current_raw_value == powerDetector_reads[i-1]):
            current_raw_value=str(int(current_raw_value)+1)                                             #casting to integer , increase 1 , then casting to string

    powerDetector_reads.append(current_raw_value)
    RS232.Uart_clear_buffers()                                                                          #clear uart buffers
    time.sleep(0.1)
    print(f'{pd_start+i},{powerDetector_reads[i]}')  #print with our paramters
    f.write(f'{pd_start+i},{powerDetector_reads[i]}\n')
table = ' '.join(powerDetector_reads)                                                                   #convert list to string - required for sending to uart
print (table)                                                                                           #print the table for debugging
Signal_Driver.set_sig_freq_and_amp(PowerDetector_freq, pd_start+cable_loss)




#Saving the results in HW device - dpam (command with 2 sending steps)
RS232.writeToUartCli("control mode ate") #enter to ATE mode
RS232.writeToUartCli_power_detector(f'setup pdet write {PowerDetector_pdetname} dbm {pd_start} points {PowerDetector_NumberOfSteps} table:')
RS232.writeToUartCli(table)

#Saving the results in file
f.write(f'setup pdet write {PowerDetector_pdetname} dbm {pd_start} points {PowerDetector_NumberOfSteps} table:\n')
f.write(table)
f.close()

#Verification by reading the values from dpam
current_raw_value = RS232.writeToUartCli("setup pdet read ul_pdet")
if len(current_raw_value)>10:
    RS232.writeToUartCli("control mode ate")
    current_raw_value = current_raw_value.decode('utf-8') #remove b' from the list values(bytes Representation) casting bytes to string
    raw_value_list_from_nvram = []
    raw_value_list_from_nvram = current_raw_value.split()
    raw_value_calib_table = []
    raw_value_calib_table = table.split()

    #compare the two lists
    if len(set(raw_value_calib_table) & set(raw_value_list_from_nvram))==len(raw_value_calib_table):
        print("Pass")
    else:
        print("Fail")
else:
    print("Fail")

