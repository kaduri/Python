from ctypes import*
import os
import re
visadll=cdll.LoadLibrary(os.path.dirname(os.path.abspath(__file__))+"\\PythonVISA.dll")

#visadll=cdll.LoadLibrary("C:\\DIGITAL_PROJECT\\CPRI_CONFIGURATOR\\3.6\\CPRI_Config_GUI_3_6"+"\\PythonVISA.dll")

def VISAFind(findExpression="?*"):
    """
GPIB?*INSTR Matches GPIB0::2::INSTR, GPIB1::1::1::INSTR, and GPIB-VXI1::8::INSTR. 
GPIB[0-9]*::?*INSTR Matches GPIB0::2::INSTR and GPIB1::1::1::INSTR but not GPIB-VXI1::8::INSTR. 
GPIB[^0]::?*INSTR Matches GPIB1::1::1::INSTR but not GPIB0::2::INSTR or GPIB12::8::INSTR. 
VXI?*INSTR Matches VXI0::1::INSTR but not GPIB-VXI0::1::INSTR. 
GPIB-VXI?*INSTR Matches GPIB-VXI0::1::INSTR but not VXI0::1::INSTR. 
?*VXI[0-9]*::?*INSTR Matches VXI0::1::INSTR and GPIB-VXI0::1::INSTR. 
ASRL[0-9]*::?*INSTR Matches ASRL1::INSTR but not VXI0::5::INSTR. 
ASRL1+::INSTR Matches ASRL1::INSTR and ASRL11::INSTR but not ASRL2::INSTR. 
(GPIB|VXI)?*INSTR Matches GPIB1::5::INSTR and VXI0::3::INSTR but not ASRL2::INSTR. 
(GPIB0|VXI0)::1::INSTR Matches GPIB0::1::INSTR and VXI0::1::INSTR. 
?*INSTR Matches all INSTR (device) resources. 
?*VXI[0-9]*::?*MEMACC Matches VXI0::MEMACC and GPIB-VXI1::MEMACC. 
VXI0::?* Matches VXI0::1::INSTR, VXI0::2::INSTR, and VXI0::MEMACC. 
?* (default) Matches all resources. 
visa://hostname/?* Matches all resources on the specified remote system. You can set the hostname as either an IP address (dot-notation) or a network machine name. This remote system does not need to be a configured remote system. 
/?* Matches all resources on the local machine. Does not query configured remote systems. 
visa:/ASRL?*INSTR Matches all ASRL resources on the local machine and returns them in URL format, such as visa:/ASRL1::INSTR. 
    """
    class Addresses:
        def __init__(self,addr):
            self.__count__=addr[0]
            self.__addresses__=addr[1]
        @property
        def count(self):
            return self.__count__
        @property
        def address(self):
            r=re.compile(";{3}")
            return r.split(self.__addresses__.strip())
    count=c_uint()
    s = create_string_buffer(b'\000' * 1000)
    visadll.VISAFind(bytes(findExpression,'utf-8'),s,byref(count))
    addr=(count.value,s.value.decode())
    return  Addresses(addr)

class Instr:
    def __init__(self,address):
        self.address=bytes(address,'utf-8')
    def Write(self,strBuffer):
        visadll.VISAWrite(self.address,bytes(strBuffer,'utf-8'))
    def Read(self,numOfBytes=256):
        s = create_string_buffer(b'\000' * numOfBytes)
        visadll.VISARead(self.address,numOfBytes,s)
        return s.value.decode()
    def Query(self,query,numOfBytes=256):
        self.Write(query)
        return self.Read(numOfBytes)
